script.module.rpyc
==================

Kodi addon of the RPyC library, see https://github.com/tomerfiliba/rpyc
