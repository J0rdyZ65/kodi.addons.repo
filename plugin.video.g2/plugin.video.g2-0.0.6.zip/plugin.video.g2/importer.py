# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2020 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals
from __future__ import print_function

import os
import sys
import pkgutil


__all__ = ['install', 'walk_packages']


_SANDBOX_NAMESPACE_SEP = '@'
_SANDBOXED_PATHS = {}
_LOG_MODULES = []


try:
    import xbmc
    import xbmcaddon

    def install(sandbox_addons=None, debug=False):
        """
        The :sandbox_addons: is a list of addons identifiers to be sandboxed.
        If :sandbox_addons: list is not empty, the ImpImporterSandbox importer is added to the sys.path_hooks.
        The ImpImporterSandbox importer handles the imports for the modules under the specified addons by adding
        a sandbox prefix to the module identifier equal to the addon identifier itself.

        If :debug: is True, the logging of the sandboxing importer/loader is enabled.
        """
        addons_root = None
        for addon_id in sandbox_addons or []:
            if not addons_root:
                addons_root = os.path.join(xbmc.translatePath('special://home').decode('utf-8'), 'addons') # decode kodi dirname
                addons_ids = os.listdir(addons_root)
            if addon_id not in addons_ids:
                continue
            addon_path = os.path.join(addons_root, addon_id)
            sandbox = _normalize_sandbox_name(os.path.basename(addon_path))
            for path in (addon_path, os.path.realpath(addon_path)):
                if path not in _SANDBOXED_PATHS:
                    _SANDBOXED_PATHS[path] = sandbox
            if debug:
                _LOG_MODULES.append(sandbox)

        if _SANDBOXED_PATHS and ImpImporterSandbox not in sys.path_hooks:
            sys.path_hooks.insert(0, ImpImporterSandbox)
            xbmc.log('importer: installed sandbox importer on sys.path_hooks[0]')

        try:
            import decoder

            addon_root = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path')).decode('utf-8') # decode kodi filename
            decoder.install_cbc_importer([os.path.join(addon_root, 'g2', k) for k in ('resolvers', 'providers')])
        except Exception as ex:
            xbmc.log('importer: %s' % repr(ex))


    def _log(obj, iden, msg, *args):
        if '*' in _LOG_MODULES or obj.sandbox in _LOG_MODULES:
            xbmc.log('[%s%s] %s%s' % (
                sys.argv[0], '' if len(sys.argv) <= 1 else ':'+sys.argv[1],
                '%s(%s)' % (obj.__class__.__name__, iden),
                msg % args))

except ImportError:
    pass
except Exception as ex:
    print('[%s] %s' % (sys.argv[0], ex), file=sys.stderr)


def _get_importer(path_item):
    try:
        importer = _get_importer.cache[path_item]
    except Exception as ex:
        if isinstance(ex, AttributeError):
            _get_importer.cache = {}
        elif not isinstance(ex, KeyError):
            raise ex
        for path_hook in sys.path_hooks:
            if path_hook != ImpImporterSandbox:
                try:
                    importer = path_hook(path_item)
                    break
                except ImportError:
                    pass
        else:
            importer = None
        _get_importer.cache.setdefault(path_item, importer)

    if importer is None:
        try:
            importer = pkgutil.ImpImporter(path_item)
        except ImportError:
            importer = None
    return importer


def _normalize_sandbox_name(name):
    return name.replace('.', '_')


def _name_is_sandboxed(fullname):
    return _SANDBOX_NAMESPACE_SEP in fullname


def _name_sandbox(sandbox, fullname):
    if _name_is_sandboxed(fullname) or not sandbox:
        return fullname
    return sandbox+_SANDBOX_NAMESPACE_SEP+fullname


def _name_get_sandbox(fullname):
    return None if not _name_is_sandboxed(fullname) else fullname.split(_SANDBOX_NAMESPACE_SEP, 1)[0]


def _name_desandbox(fullname):
    return fullname if not _name_is_sandboxed(fullname) else fullname.split(_SANDBOX_NAMESPACE_SEP, 1)[1]


def walk_packages(path=None, prefix='', onerror=None):
    for package, name, is_pkg in pkgutil.walk_packages(path, prefix, onerror):
        yield package, _name_desandbox(name), is_pkg


class ImpImporterSandbox(pkgutil.ImpImporter):
    """
        The ImpImporterSandbox class enhance the standard import mechanism
        by creating a separate module namespace for each addon.
        This allow the coexistence in the same python thread of different addons
        using the same module namespace regardless of the import model used.
    """
    def __init__(self, path=None):
        pkgutil.ImpImporter.__init__(self, path)
        self.sandbox = None
        self._log('')

        for hpath, sandbox in _SANDBOXED_PATHS.items():
            if path and path.startswith(hpath):
                self.sandbox = sandbox
                break
        else:
            self._log(': not handled')
            raise ImportError

        self.importer = _get_importer(path or self.path)
        self._log(': sandboxed using %s%s prefix, importer is %s', self.sandbox, _SANDBOX_NAMESPACE_SEP, self.importer)

    def find_module(self, fullname, path=None):
        self._log('.find_module(%s, %s)', fullname, path)

        loader = self.importer.find_module(fullname, path)
        self._log('.find_module(%s, %s): %s', fullname, path, loader)

        return None if not loader else ImpLoaderSandbox(fullname, loader)

    def iter_modules(self, prefix=''):
        self._log('.iter_modules(%s)', prefix)

        for name, is_pkg in self.importer.iter_modules(prefix):
            self._log('.iter_modules(%s): yield %s, %s', prefix, _name_sandbox(self.sandbox, name), is_pkg)
            yield _name_sandbox(self.sandbox, name), is_pkg

    def _log(self, msg, *args):
        _log(self, self.path, msg, *args)


class ImpLoaderSandbox(object):
    def __init__(self, fullname, loader):
        self.fullname = fullname
        self.loader = loader
        self.sandbox = _name_get_sandbox(fullname)
        self._log(': sandboxed using %s%s prefix, loader is %s', self.sandbox, _SANDBOX_NAMESPACE_SEP, self.loader)

    def load_module(self, fullname):
        self._log('.load_module(%s)', fullname)

        sandboxfullname = _name_sandbox(self.sandbox, fullname)

        #
        # NOTE: Kodi, before running an addon, seems to load the top level packages found in the
        #   required section of the addon itself (e.g. for the dependency script.module.requests,
        #   Kodi loads the "requests" package found in "addons/script.module.requests/lib/" directory).
        #   This is done before the importer machinery is hooked up by the addon, so the required
        #   top level packages are inserted in sys.modules not sandboxed (e.g. as "requests" not as
        #   "script_module_requests@requests"). This is not a problem from a conflict point of
        #   view as these packages should not conflict at all and, if they are, the module that imports it
        #   can change the import statement. However, subsequently, this importer module fails to find them.
        #   The check below is performed to verify this scenario and eventually patch the sys.modules.
        #
        cleanfullname = _name_desandbox(sandboxfullname)
        grandparent = cleanfullname.split('.')[0]
        if grandparent != cleanfullname:
            sandboxgrandparent = _name_sandbox(self.sandbox, grandparent)
            if sandboxgrandparent in sys.modules:
                self._log('.load_module(%s): sandboxed grand parent module %s found in the cache: %s',
                          fullname, sandboxgrandparent, sys.modules[sandboxgrandparent])
            elif grandparent in sys.modules:
                self._log('.load_module(%s): grand parent module %s found in the cache: %s',
                          fullname, grandparent, sys.modules[grandparent])
                # The top level module is already loaded in sys.modules not sandboxed
                sys.modules[sandboxgrandparent] = sys.modules[grandparent]

        if sandboxfullname in sys.modules:
            mod = sys.modules[sandboxfullname]
            self._log('.load_module(%s): module %s found in the cache: %s', fullname, sandboxfullname, mod)
        else:
            self._log('.load_module(%s): loading module %s...', fullname, sandboxfullname)
            mod = self.loader.load_module(sandboxfullname)

        if not mod:
            self._log('load_module(..., %s): loading module %s failed'%(fullname, sandboxfullname))
        else:
            self._log('load_module(..., %s): %s loaded: __name__=%s, __file__=%s, __package__=%s, __path__=%s'%
                      (fullname, sandboxfullname, mod.__name__, mod.__file__, mod.__package__,
                       mod.__path__ if hasattr(mod, '__path__') else 'NO ATTRIBUTE'))

        return mod

    def _log(self, msg, *args):
        _log(self, self.fullname, msg, *args)
