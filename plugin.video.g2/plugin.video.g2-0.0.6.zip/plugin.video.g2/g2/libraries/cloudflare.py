# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2017-2020 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import sys
import abc
import new
import datetime

from g2.platforms import log
from g2.platforms import addon


class CfbypassBase(object):
    __metaclass__ = abc.ABCMeta

    @abc.abstractproperty
    def priority(self):
        raise NotImplementedError

    @abc.abstractmethod
    def check(self, res):
        raise NotImplementedError

    @abc.abstractmethod
    def bypass(self, res, user_agent, cookiesjar):
        raise NotImplementedError


class CfbypassCfscrape(CfbypassBase):
    priority = 2

    def __init__(self):
        self.conn = None

    @classmethod
    def _cloudflare_bypass(cls):
        from .cloudflares import cfscrape
        return cfscrape.create_scraper()

    def _load_execjs(self):
        if 'execjs' in sys.modules:
            return

        try:
            # First try with the installed execjs module
            import execjs
            return
        except ImportError:
            pass

        # Let's see if a remote Node.js can be reached
        nodejs = addon.setting('nodejs')
        if not nodejs:
            raise Exception('missing nodejs setting')

        import rpyc
        self.conn = rpyc.utils.factory.ssl_connect(nodejs.split(':')[0], port=str(nodejs.split(':')[1])) # NOTE: in py2 port must be str!

        if self.conn:
            log.notice('{m}: connected to remote Node.js on %s', nodejs)
        else:
            raise Exception('unable to connect to remote Node.js on %s' % nodejs)

        # Monkey patching the sys.modules to emulate an installed execjs
        sys.modules['execjs'] = new.module(str('execjs')) # [py2] str() for non unicode modules names!
        sys.modules['execjs'].__dict__['__conn__'] = self.conn
        sys.modules['execjs'].__dict__['get'] = self.conn.root.get

    def check(self, res):
        cfb = self._cloudflare_bypass()
        return cfb.is_cloudflare_iuam_challenge(res)

    def bypass(self, res, user_agent, cookiesjar):
        self._load_execjs()
        cfb = self._cloudflare_bypass()
        cfb.headers['User-Agent'] = user_agent
        cfb.cookies = cookiesjar
        return cfb.solve_cf_challenge(res)


class CfbypassCloudscraper(CfbypassBase):
    priority = 1

    @classmethod
    def _cloudflare_bypass(cls, **kwargs):
        from .cloudflares import cloudscraper
        return cloudscraper.create_scraper(debug=False, **kwargs)

    def check(self, res):
        return self._cloudflare_bypass().is_Challenge_Request(res)

    def bypass(self, res, user_agent, cookiesjar):
        cfb = self._cloudflare_bypass()
        cfb.headers['User-Agent'] = user_agent
        cfb.cookies = cookiesjar
        return cfb.Challenge_Response(res)


def _all_subclasses(cls):
    return set(cls.__subclasses__()).union(
        [s for c in cls.__subclasses__() for s in _all_subclasses(c)])


_ALL_CFBYPASS = sorted(_all_subclasses(CfbypassBase), key=lambda c: c.priority)


def bypass(res, user_agent, cookiesjar, *_kwargs):
    """Return the requests response object of the target page by applying the available bypass mechanisms.

    If none of the methods detects the cloudflare protection, the original response is returned.
    """

    detected = 0
    for cfbypass_class in _ALL_CFBYPASS:
        try:
            started = datetime.datetime.now()
            cfbypass = cfbypass_class()
            if not cfbypass.check(res):
                log.debug('{m}.{f}: %s: no cloudflare protection detected for %s', cfbypass_class.__name__,
                          res.request.url)
                continue
            detected += 1
            log.debug('{m}.{f}: %s: cloudflare protection detected[%d] for %s', cfbypass_class.__name__,
                      detected, res.request.url)
            res = cfbypass.bypass(res, user_agent, cookiesjar)
            if not cfbypass.check(res):
                elapsed = datetime.datetime.now() - started
                log.notice('{m}: %s: cloudflare bypass in %.1d secs for %s',
                           cfbypass_class.__name__, elapsed.seconds+elapsed.microseconds/1000000., res.request.url)
                break
            log.notice('{m}: %s: cloudflare not bypassed for %s', cfbypass_class.__name__, res.request.url)
        except Exception as ex:
            log.notice('{m}.{f}: %s: %s', cfbypass_class.__name__, repr(ex))
    else:
        if detected:
            return None

    return res
