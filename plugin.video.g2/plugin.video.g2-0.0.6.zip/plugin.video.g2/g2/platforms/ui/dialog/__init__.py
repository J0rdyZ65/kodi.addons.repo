# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2017-2020 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import collections

import xbmc
import xbmcgui

from g2.libraries import workers

from ... import log
from ... import info as platform_info
from ... import addon
from ..media import addon_icon


__all__ = ['progress', 'progress_bg', 'busy', 'idle', 'ok', 'yesno', 'info', 'error', 'keyboard']


_ADDON_SETTINGS_WINDOW_ID = 10140
_TEXTVIEWER_WINDOW_ID = 10147
_DIALOG = xbmcgui.Dialog()


class EventHandler(object):
    """Window Event Handler helper class"""

    ACTION_FOCUS = 'focus'

    def __init__(self):
        self.clicks = {}
        self.actions = {}
        self.focuses = {}
        self.threads = {}
        self.thread_lock = workers.Lock()

    def busydialog(self):
        def decorator(func):
            def wrapper(*args, **kwargs):
                busy()
                try:
                    res = func(*args, **kwargs)
                except Exception as ex:
                    log.notice('%s.{f}: %s: %s', self.__class__.__name__, func, repr(ex))
                    res = None
                finally:
                    idle()
                return res
            return wrapper
        return decorator

    def thread(self, thread_name):
        def decorator(func):
            def wrapper(*args, **kwargs):
                self._add_thread_activity(thread_name, (func, args, kwargs))
                return self._run_thread(thread_name)
            return wrapper
        return decorator

    def join(self, thread_name, timeout=None, die=None):
        with self.thread_lock:
            thread = self._running_thread(thread_name)
            if thread:
                if die is not None:
                    thread.die = die
                    self.threads[thread_name]['die'] = die
        if thread:
            log.debug('%s.{f}: %s: waiting to finish (die is %s)', self.__class__.__name__, thread_name, die)
            thread.join(timeout)

    def is_alive(self, thread_name):
        with self.thread_lock:
            return self._running_thread(thread_name) is not None

    @staticmethod
    def should_i_die():
        try:
            return workers.current_thread().die
        except Exception:
            return False

    def _running_thread(self, thread_name):
        return None if (not self.threads.get(thread_name, {'thread': None})['thread'] or
                        not self.threads[thread_name]['thread'].is_alive() or
                        self.threads[thread_name]['thread'].stopped) else self.threads[thread_name]['thread']

    def _add_thread_activity(self, thread_name, activity):
        with self.thread_lock:
            if thread_name not in self.threads:
                self.threads[thread_name] = {
                    'thread': None,
                    'die': False,
                    'activities': [],
                    }
            self.threads[thread_name]['activities'].append(activity)

    def _run_thread(self, thread_name):
        try:
            with self.thread_lock:
                thd = self._running_thread(thread_name)
                if thd:
                    return thd
                if self.threads[thread_name]['thread']:
                    if self.threads[thread_name]['thread'].exc:
                        log.error('%s.{f}: %s: %s',
                                  self.__class__.__name__, thread_name, repr(self.threads[thread_name]['thread'].exc))
                    if self.threads[thread_name]['thread'].exc_traceback:
                        log.error('%s.{f}: %s: %s',
                                  self.__class__.__name__, thread_name, self.threads[thread_name]['thread'].exc_traceback)
                if not self.threads[thread_name]['activities']:
                    log.debug('%s.{f}: %s: completed', self.__class__.__name__, thread_name)
                    del self.threads[thread_name]
                elif self.threads[thread_name]['die']:
                    log.debug('%s.{f}: %s: aborted at %s', self.__class__.__name__, thread_name,
                              self.threads[thread_name]['activities'][0][0])
                    del self.threads[thread_name]
                else:
                    activity = self.threads[thread_name]['activities'].pop(0)
                    self.threads[thread_name]['thread'] = workers.Thread(
                        activity[0], *activity[1],
                        threadopt_callback=(self._run_thread, (thread_name,), {}),
                        **activity[2])
                    self.threads[thread_name]['thread'].start()
                    log.debug('%s.{f}: %s: started %s', self.__class__.__name__, thread_name, activity[0])
                    return self.threads[thread_name]['thread']
        except Exception as ex:
            log.error('%s.{f}: %s: %s', self.__class__.__name__, thread_name, repr(ex))
        return None

    def click(self, control_ids):
        def decorator(func):
            for control_id in control_ids if isinstance(control_ids, list) else [control_ids]:
                self.clicks[control_id] = func
            return func
        return decorator

    def onclick(self, control_id, win):
        func = self.clicks.get(control_id)
        if func:
            log.debug('%s.{f}: calling %s', self.__class__.__name__, func)
            func(win, control_id)

    def action(self, action_type, control_ids):
        def decorator(func):
            self.actions[action_type] = self.actions.get(action_type, {})
            for control_id in control_ids if isinstance(control_ids, list) else [control_ids]:
                self.actions[action_type][control_id] = func
            return func
        return decorator

    def onaction(self, action, win):
        for action_type in [action.getId(), self.ACTION_FOCUS]:
            func = self.actions.get(action_type, {}).get(win.getFocusId())
            if func:
                log.debug('%s.{f}: on action %s calling %s', self.__class__.__name__, action_type, func)
                func(win, action)

    def focus(self, control_ids):
        def decorator(func):
            for control_id in control_ids if isinstance(control_ids, list) else [control_ids]:
                self.focuses[control_id] = func
            return func
        return decorator

    def onfocus(self, control_id, win):
        func = self.focuses.get(control_id)
        if func:
            log.debug('%s.{f}: calling %s', self.__class__.__name__, func)
            func(win, control_id)


def addon_settings(category=0):
    xbmc.executebuiltin('Addon.OpenSettings(%s)' % addon.info('id'))
    xbmc.executebuiltin('SetFocus(%d)' % (category+100))
    return xbmcgui.Window(_ADDON_SETTINGS_WINDOW_ID)


def textviewer(title, text):
    xbmc.executebuiltin('ActivateWindow(%d)' % _TEXTVIEWER_WINDOW_ID)
    win = xbmcgui.Window(_TEXTVIEWER_WINDOW_ID)

    xbmc.sleep(300)
    for dummy in range(50):
        try:
            xbmc.sleep(10)
            win.getControl(1).setLabel(title)
            win.getControl(5).setText(text)
            break
        except Exception:
            pass


def progress():
    return xbmcgui.DialogProgress()


def progress_bg():
    return xbmcgui.DialogProgressBG()


def busy():
    return xbmc.executebuiltin('ActivateWindow(%s)' %
                               ('busydialog' if int(platform_info('version.major')) < 18
                                else 'busydialognocancel'))


def idle():
    return xbmc.executebuiltin('Dialog.Close(%s)' %
                               ('busydialog' if int(platform_info('version.major')) < 18
                                else 'busydialognocancel'))


def ok(heading=addon.info('name'), lines=''):
    return _DIALOG.ok(heading=heading, line1=_collate_lines(lines))


def yesno(heading=addon.info('name'), lines='', nolabel='', yeslabel=''):
    return _DIALOG.yesno(heading, line1=_collate_lines(lines), nolabel=nolabel, yeslabel=yeslabel)


def info(message, heading=addon.info('name'), icon=None, time=3000):
    _DIALOG.notification(heading, message, icon or addon_icon(), time, sound=False)


def error(message, heading=addon.info('name'), icon=None, time=5000):
    _DIALOG.notification(heading, message, icon or addon_icon(), time)


def _collate_lines(lines):
    return '[CR]'.join(lines) if isinstance(lines, collections.Sequence) and not isinstance(lines, basestring) else lines


def keyboard(heading, history=None, default=''):
    if not history or hasattr(xbmc, 'set_env'):
        dlg = xbmc.Keyboard(default or '', heading)
    else:
        from .keyboard import KeyboardDialog
        dlg = KeyboardDialog('KeyboardDialog.xml', addon.info('path'), 'Default', '720p',
                             heading=heading,
                             history=history,
                             default=default)
    dlg.doModal()

    return dlg.getText().decode('utf-8') if dlg.isConfirmed() else ''
