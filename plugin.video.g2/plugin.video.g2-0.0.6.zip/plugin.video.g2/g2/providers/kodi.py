# -*- coding: utf-8 -*-

"""
    G2 Add-on Package
    Copyright (C) 2020 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

from g2.providers.api import ProviderBase
from g2.resolvers import ResolvedURL
from g2.platforms import videolibrary


class Provider(ProviderBase):
    """Kodi provider"""

    kodi_id = 'kodi'

    info = {
        'content': ['movie', 'episode'],
        'language': ['*'],
        'sources': [kodi_id],
    }

    def search(self, content, language, meta):
        videos = videolibrary.search(content, meta)
        return [{
            'url': v['file'] + ('|movie=%d' % v['movieid'] if 'movieid' in v else '|episode=%d' % v['episodeid']),
            'title': v.get('title', v.get('showtitle')),
            'year': v.get('year'),
            } for v in videos]

    def sources(self, content, language, match):
        return [{
            'url': match['url'],
            'host': self.kodi_id,
        }]

    def resolve(self, url):
        url, video = url.rsplit('|')
        url = ResolvedURL(url)
        content, videoid = video.split('=')
        meta = videolibrary.mediainfo(content, int(videoid))
        if meta:
            url.enrich(meta={
                'type': meta[0].get('codec'),
                'width': meta[0].get('width'),
                'height': meta[0].get('height'),
            })
        return url
