# -*- coding: utf-8 -*-

[@packages] {
    # ==============
    # Addon packages
    # ==============
    'providers.italian_streamers': (
    	'A very small selection of italian streaming services',
        'github://J0rdyZ65/g2.packages/italian_streamers',
    ),
}

[@languages] {
    # ============================
    # Languages names translations
    # ============================
    'en': {
        'en': 'English',
        'it': 'Inglese',
    },
    'it': {
        'en': 'Italian',
        'it': 'Italiano',
    }
}

[@pushsites] {
    # =========================
    # Pushed url matching rules
    # =========================
    # This section specifies how to parse the pushed url.
    #
    # The key is a regular expression matching the url.
    # The value is a dict detailing how the matched url should be processed:
    #   'action'            The action triggered by the url push.
    #                       Currently only the 'sources.play' action is supported for scheduling
    #                       the playing of the video identified by other fields in the url (see below);
    #   'content'           The content type: 'movie' or 'episode';
    #   'dbids'             Tuple composed of a regular expression extracting the database identifiers
    #                       and the list of database identifiers names.
    #
    r'imdb.com/': {
        'action': 'sources.play',
        'content': 'movie',
        'dbids': (r'/title/(tt[\d]+)', 'imdb'),
    },
    r'themoviedb.org/movie/': {
        'action': 'sources.play',
        'content': 'movie',
        'dbids': (r'/movie/([\d]+)', 'tmdb'),
    },
    r'themoviedb.org/tv/': {
        'action': 'sources.play',
        'content': 'episode',
        'dbids': (r'/tv/([\d]+).*/season/([\d]+).*/episode/([\d]+)', 'tmdb', 'season', 'episode'),
    },
}

[@media] {
    # ======================
    # Resource media mapping
    # ======================
    # This section specifies how to use the images present in specific resource images addons.
    #
    # The key of the top level dictionary is the prefix to the theme name
    # The dictionary item has the following keys:
    #     'addon_id'        Kodi resource image addon id. The empty key is reserved for g2;
    #     'media_path'      relative to the addon path, specified as a list of hierarchical
    #                       folders that will be joined using the os.path.join. If omitted,
    #                       is is assumed to be ['resources', 'media'].
    #     'themes'          if set to 'folder' means that each sub-folder of the :media_path:
    #                       is a different theme whose name is the sub-folder name itself.
    #                       If omitted, the resource is assumed to represent a single theme.
    #     'mappings'        a dictionary mapping the g2 icon name (without suffix) to the
    #                       resource icon name (with or w/o suffix). If the name is the same,
    #                       the entry is not required. This key can be altogether omitted if
    #                       all the names are the same.
    #
    # Entry for the plugin.video.g2 resources/media folder
    '': {
        'themes': 'folder',
    },
    # Entry for the Exodus themes in the script.exodus.artwork addon
    'Exodus': {
        'addon_id': 'script.exodus.artwork',
        'themes': 'folder',
        'mappings': {
            'settings': 'tools.png',
            'cache': 'tools.png',
            'moviesTraktcollection': 'trakt.png',
            'moviesTraktwatchlist': 'trakt.png',
            'moviesTraktrated': 'trakt.png',
            'moviesTraktrecommendations': 'trakt.png',
            'movieUserlists': 'userlists.png',
            'mymenu': 'userlists.png',
            'moviesAdded': 'latest-movies.png',
            'movieSearch': 'search.png',
            'moviePerson': 'people-search.png',
            'movieYears': 'years.png',
            'movieGenres': 'genres.png',
            'movieCertificates': 'certificates.png',
            'moviesTrending': 'featured.png',
            'moviesPopular': 'most-popular.png',
            'moviesViews': 'most-voted.png',
            'moviesBoxoffice': 'box-office.png',
            'moviesOscars': 'oscar-winners.png',
            'moviesTheaters': 'in-theaters.png',
            'tvSearch': 'search.png',
            'tvshowsTrending': 'featured.png',
            'tvshowsPopular': 'most-popular.png',
        },
    },
    # Entry for the Covenant themes in the script.covenant.artwork addon
    'Covenant': {
        'addon_id': 'script.covenant.artwork',
        'themes': 'folder',
        'mappings': {
            'settings': 'tools.png',
            'cache': 'tools.png',
            'moviesTraktcollection': 'trakt.png',
            'moviesTraktwatchlist': 'trakt.png',
            'moviesTraktrated': 'trakt.png',
            'moviesTraktrecommendations': 'trakt.png',
            'movieUserlists': 'userlists.png',
            'mymenu': 'userlists.png',
            'moviesAdded': 'latest-movies.png',
            'movieSearch': 'search.png',
            'moviePerson': 'people-search.png',
            'movieYears': 'years.png',
            'movieGenres': 'genres.png',
            'movieCertificates': 'certificates.png',
            'moviesTrending': 'featured.png',
            'moviesPopular': 'most-popular.png',
            'moviesViews': 'most-voted.png',
            'moviesBoxoffice': 'box-office.png',
            'moviesOscars': 'oscar-winners.png',
            'moviesTheaters': 'in-theaters.png',
            'tvSearch': 'search.png',
            'tvshowsTrending': 'featured.png',
            'tvshowsPopular': 'most-popular.png',
        },
    },
}

[@hosts_icons] {
    'akvid': 'http://akvideo.stream/img/logo.png',
    'akvideo': 'http://akvideo.stream/img/logo.png',
    'backin': 'http://backin.net/images/logo_bw.png',
    'deltabit': 'http://deltabit.co/img/logo.png',
    'flashx': 'https://static.flashx.to/images/logo.png',
    'gounlimited.to': 'https://gounlimited.to/theme_2/assets/images/logo-light.png',
    'kodi': 'https://codedocs.xyz/AlwinEsch/kodi/Thumbnail-symbol-whitebg-small.jpg',
    'megadrive': 'https://mega.nz/favicon.ico',
    'mixdrop': 'https://mixdrop.co/imgs/mixdrop-logo2.png',
    'okru': 'http://st.mycdn.me/res/i/p/anonym/logo_48x82.png',
    'speedvideo': 'http://speedvideo.net/img/speed_logo_red.png',
    'subyshare': 'https://subyshare.com/img/logo.png',
    'thevideome': 'https://vev.io/icons/9cef074a405c1d55b094c0d43055dd73/favicon-32x32.png',
    'tusfiles': 'https://tusfiles.net/i/TFLOGO.png',
    'wstream': 'https://wstream.video/img/logo.png',
    'uploadgig': 'http://uploadgig.com/static/tpl2/img/logo.png',
    'uptobox': 'https://static.uptobox.com/images/logo.png',
    'videowood': 'http://videowood.tv/assets/images/videowood_res.png',
    'netflix': 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Netflix_icon.svg/240px-Netflix_icon.svg.png',
    'raiplay': 'http://www.rai.it/dl/RaiTV/2012/images/ogImage.jpg',
    'vidto': 'http://vidtome.co/images/header-logo.png',
    'vidtome': 'http://vidtome.co/images/header-logo.png',
    'upstream.to': 'https://upstream.to/mngez/images/logo.png',
    'youtube': 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/YouTube_icon.png/320px-YouTube_icon.png',
}

[@actions] {
    # Automagically generated: do NOT modify!!!
    'changelog.show': {},
    'tvshows.tvshowlist': {'url': 'str'},
    'tvshows.menu': {},
    'tvshows.episodes': {'tvdb': 'int', 'season': 'int', 'imdb': 'str'},
    'tvshows.deletebookmark': {'meta': 'dict'},
    'tvshows.genres': {},
    'tvshows.addtolibrary': {'meta': 'dict', 'title': 'str'},
    'tvshows.seasons': {'tvdb': 'int', 'imdb': 'str'},
    'tvshows.bookmarked': {},
    'tvshows.searchbytitle': {},
    'tvshows.searchbyyear': {},
    'tools.packagemanager': {},
    'tools.advancedsettings': {},
    'tools.addonsettings': {'category': 'int'},
    'tools.menu': {},
    'tools.clearcache': {},
    'tools.updatemedia': {},
    'tools.factoryreset': {},
    'sources.contentlanguage': {},
    'sources.play': {'content': 'str', 'meta': 'dict'},
    'sources.clearsourcescache': {'meta': 'dict', 'name': 'str'},
    'sources.watched': {'content': 'str', 'seen': 'bool', 'meta': 'dict'},
    'player.notify': {},
    'movies.certifications': {},
    'movies.genres': {},
    'movies.addtolibrary': {'meta': 'dict', 'title': 'str'},
    'movies.bookmarked': {},
    'movies.personlist': {'url': 'str'},
    'movies.searchbyperson': {},
    'movies.movielist': {'url': 'str'},
    'movies.menu': {},
    'movies.searchbytitle': {},
    'movies.searchbyyear': {},
    'movies.deletebookmark': {'meta': 'dict'},
    'auth.trakt': {},
    'auth.pushbullet': {},
    'auth.tmdb': {},
    'main.menu': {},
    'videolibrary.update': {'content': 'str', 'meta': 'dict', 'title': 'str'},
}
