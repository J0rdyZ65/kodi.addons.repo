# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import xbmc
from xbmc import Player, sleep

from .. import actions
from . import d
from . import dialog
from .dialog import busy as busydialog, idle
from .media import addon_icon, addon_poster, addon_banner, addon_thumb, addon_fanart, addon_next, media, resource_themes


_MONITOR = xbmc.Monitor()


def abort_requested(timeout=None):
    return _MONITOR.waitForAbort(timeout) if timeout else _MONITOR.abortRequested()


def refresh(action=None, **kwargs):
    return xbmc.executebuiltin('Container.Refresh') if not action else \
           xbmc.executebuiltin('Container.Update(%s)'%actions.url(action, **kwargs))


def player_info():
    return (xbmc.getInfoLabel('VideoPlayer.Title'),
            xbmc.getInfoLabel('VideoPlayer.Year'),
            xbmc.getInfoLabel('VideoPlayer.mpaa'),
            xbmc.getInfoLabel('VideoPlayer.IMDBNumber'))
