# -*- coding: utf-8 -*-

"""
MIT License

Copyright (c) 2019 VeNoMouS
Copyright (c) 2015 Anorov

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import re
import operator as op

from .cfscrape import CloudflareScraper


class CloudflareScraperNative(CloudflareScraper):
    def solve_challenge(self, body, domain):
        operators = {
            '+': op.add,
            '-': op.sub,
            '*': op.mul,
            '/': op.truediv
        }

        def jsfuckToNumber(jsFuck):
            t = ''

            split_numbers = re.compile(r'-?\d+').findall

            for i in re.findall(
                r'\((?:\d|\+|\-)*\)',
                jsFuck.replace('!+[]', '1').replace('!![]', '1').replace('[]', '0').lstrip('+').replace('(+', '(')
            ):
                t = '{}{}'.format(t, sum(int(x) for x in split_numbers(i)))

            return int(t)

        def divisorMath(payload, needle, domain):
            jsfuckMath = payload.split('/')
            if needle in jsfuckMath[1]:
                expression = re.findall(r"^(.*?)(.)\(function", jsfuckMath[1])[0]
                expression_value = operators[expression[1]](
                    float(jsfuckToNumber(expression[0])),
                    float(ord(domain[jsfuckToNumber(jsfuckMath[1][
                        jsfuckMath[1].find('"("+p+")")}') + len('"("+p+")")}'):-2
                    ])]))
                )
            else:
                expression_value = jsfuckToNumber(jsfuckMath[1])

            expression_value = jsfuckToNumber(jsfuckMath[0]) / float(expression_value)

            return expression_value

        jschl_answer = 0

        jsfuckChallenge = re.search(
            r"setTimeout\(function\(\){\s+var.*?f,\s*(?P<variable>\w+).*?:(?P<init>\S+)};"
            r".*?\('challenge-form'\);\s+;(?P<challenge>.*?a\.value)"
            r"(?:[^{<>]*},\s*(?P<ms>\d{4,}))?"
            r"(?:.*id=\"cf-dn-.*?>(?P<k>\S+)<)?",
            body,
            re.DOTALL | re.MULTILINE
        ).groupdict()

        jsfuckChallenge['challenge'] = re.finditer(
            r'{}.*?([+\-*/])=(.*?);(?=a\.value|{})'.format(
                jsfuckChallenge['variable'],
                jsfuckChallenge['variable']
            ),
            jsfuckChallenge['challenge']
        )

        if '/' in jsfuckChallenge['init']:
            val = jsfuckChallenge['init'].split('/')
            jschl_answer = jsfuckToNumber(val[0]) / float(jsfuckToNumber(val[1]))
        else:
            jschl_answer = jsfuckToNumber(jsfuckChallenge['init'])

        for expressionMatch in jsfuckChallenge['challenge']:
            oper, expression = expressionMatch.groups()

            if '/' in expression:
                expression_value = divisorMath(expression, 'function(p)', domain)
            else:
                if 'Element' in expression:
                    expression_value = divisorMath(jsfuckChallenge['k'], '"("+p+")")}', domain)
                else:
                    expression_value = jsfuckToNumber(expression)

            jschl_answer = operators[oper](jschl_answer, expression_value)

        if not jsfuckChallenge['k'] and '+ t.length' in body:
            jschl_answer += len(domain)

        delay = self.delay or (float(jsfuckChallenge['ms']) / float(1000) if jsfuckChallenge['ms'] else 8)

        return '{0:.10f}'.format(jschl_answer), delay


create_scraper = CloudflareScraperNative.create_scraper
