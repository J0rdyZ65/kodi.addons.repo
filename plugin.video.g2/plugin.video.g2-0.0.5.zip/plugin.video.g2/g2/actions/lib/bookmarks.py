# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

from g2.libraries.database import SettingsDB


class Bookmarks(SettingsDB):
    def __init__(self, content=None):
        super(Bookmarks, self).__init__(
            'bookmarks',
            ('imdb', ('season', 'INTEGER', 0), ('episode', 'INTEGER', 0)),
            (('bookmarktime', 'INTEGER'), 'url'),
            order_clause=lambda cns: ' ORDER BY %s DESC' % cns[-1],
            timestamp=True,
            version=1)
        self.iterkey = None if not content else \
            {'season': 0, 'episode': 0} if content == 'movie' else {'~season': 0, '~episode': 0}

    def __len__(self):
        return super(Bookmarks, self).__call__(self.iterkey)

    def iterkeys(self, *_args):
        return super(Bookmarks, self).iterkeys(self.iterkey)

    def iteritems(self, *_args):
        return super(Bookmarks, self).iteritems(self.iterkey)
