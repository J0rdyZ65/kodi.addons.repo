# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

from g2.platforms import ui
from g2.platforms.language import _
from g2.platforms.actions import action


@action()
def menu():
    ui.d.add(_('Movies'), 'movies', 'DefaultMovies.png', 'movies.menu')
    ui.d.add(_('TV Series'), 'tvshows', 'DefaultTVShows.png', 'tvshows.menu')
    ui.d.add(_('Tools'), 'tools', 'DefaultAddonProgram.png', 'tools.menu')
    ui.d.end()
