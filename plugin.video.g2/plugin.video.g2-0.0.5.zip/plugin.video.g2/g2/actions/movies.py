# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

from g2 import dbs

from g2.platforms import ui
from g2.platforms import addon
from g2.platforms import actions
from g2.platforms import videolibrary
from g2.platforms.language import _
from g2.platforms.actions import action

from .lib.bookmarks import Bookmarks


@action()
def menu():
    if Bookmarks('movie'):
        ui.d.add(_('Keep Watching'), 'movieUserlists', 'DefaultMovies.png', 'movies.bookmarked')

    ui.d.add(_('Recommendations [[UPPERCASE]{provider}[/UPPERCASE]]',
               provider=dbs.resolve('movies_recommendations{}', dbsopt_provider=True)),
             'moviesRecommendations', 'DefaultMovies.png', 'movies.movielist', url=dbs.resolve('movies_recommendations{}'))

    ui.d.add(_('Latest Movies [[UPPERCASE]{provider}[/UPPERCASE]]',
               provider=dbs.resolve('movies_recently_added{}', dbsopt_provider=True)),
             'moviesAdded', 'DefaultRecentlyAddedMovies.png', 'movies.movielist', url=dbs.resolve('movies_recently_added{}'))

    ui.d.add(_('Search by Title'), 'movieSearch', 'DefaultMovies.png', 'movies.searchbytitle', is_folder=False)
    ui.d.add(_('Search by Person'), 'moviePerson', 'DefaultMovies.png', 'movies.searchbyperson', is_folder=False)
    ui.d.add(_('Search by Year'), 'movieYear', 'DefaultYear.png', 'movies.searchbyyear', is_folder=False)

    ui.d.add(_('Genres'), 'movieGenres', 'DefaultGenre.png', 'movies.genres')
    ui.d.add(_('Certificates'), 'movieCertificates', 'DefaultMovies.png', 'movies.certifications')

    ui.d.add(_('Featured'), 'movies', 'DefaultRecentlyAddedMovies.png',
             'movies.movielist', url=dbs.resolve('movies_featured{}'))
    ui.d.add(_('People Watching'), 'moviesTrending', 'DefaultRecentlyAddedMovies.png',
             'movies.movielist', url=dbs.resolve('movies_trending{}'))
    ui.d.add(_('Most Popular'), 'moviesPopular', 'DefaultMovies.png',
             'movies.movielist', url=dbs.resolve('movies_popular{}'))
    ui.d.add(_('Most Voted'), 'moviesViews', 'DefaultMovies.png',
             'movies.movielist', url=dbs.resolve('movies_toprated{}'))
    ui.d.add(_('Box Office'), 'moviesBoxoffice', 'DefaultMovies.png',
             'movies.movielist', url=dbs.resolve('movies_boxoffice{}'))
    ui.d.add(_('Oscar Winners'), 'moviesOscars', 'DefaultMovies.png',
             'movies.movielist', url=dbs.resolve('movies_oscar{}'))
    ui.d.add(_('In Theaters'), 'moviesTheaters', 'DefaultRecentlyAddedMovies.png',
             'movies.movielist', url=dbs.resolve('movies_theaters{}'))

    if not addon.setting('trakt_user') or addon.setting('trakt_enabled') != 'true':
        ui.d.add(_('Configure your Trakt account'), 'moviesTraktcollection', 'DefaultMovies.png',
                 'tools.addonsettings', category=1, is_folder=False)

    ui.d.end()


@action()
def bookmarked():
    def elapsed2str(secs):
        mins, secs = divmod(secs, 60)
        hours, mins = divmod(mins, 60)
        return '%d:%02d:%02d' % (hours, mins, secs)

    items = [{
        'imdb': k['imdb'],
        'bookmarktime': b['bookmarktime'],
        } for k, b in Bookmarks('movie').iteritems()]
    items = items[0:20]

    dbs.meta(items)

    for i in items:
        i['label.format'] = _('[B][{bookmarktime}][/B] {{label}}', bookmarktime=elapsed2str(i['bookmarktime']))
        i['action'] = actions.url('sources.play', content='movie', meta=i)
        i['commands'] = [(_('Delete bookmark'), actions.plugin('movies.deletebookmark', meta=i))]

    # Disable the sort methods so that the latest video watched is shown first
    ui.d.addcontents(items, content='movie', sort_methods=())


@action(dict)
def deletebookmark(meta):
    bookmarks = Bookmarks()
    if meta in bookmarks:
        del bookmarks[meta]
        ui.refresh()


@action()
def searchbytitle():
    query = ui.dialog.keyboard(_('Movie search'), history='movie-title')
    if query:
        url = dbs.resolve('movies{title}', title=query)
        ui.refresh('movies.movielist', url=url)


@action()
def searchbyperson():
    query = ui.dialog.keyboard(_('Person search'), history='person-name')
    if query:
        url = dbs.resolve('persons{name}', name=query)
        ui.refresh('movies.personlist', url=url)


@action()
def searchbyyear():
    query = ui.dialog.keyboard(_('Year search'), history='movie-year')
    if query:
        url = dbs.resolve('movies{year}', year=query)
        ui.refresh('movies.movielist', url=url)


@action()
def genres():
    items = dbs.genres('movie')
    for i in items:
        image = i.get('image')
        if not image:
            image = 'DefaultGenre.png' # (fixme) [UI] Need a table mapping genre 'id' to different icons
        i.update({
            'action': 'movies.movielist',
            'url': dbs.resolve('movies{genre_id}', genre_id=i['id']),
            'image': image,
        })

    ui.d.adds(items)


@action()
def certifications():
    items = dbs.certifications()
    items = sorted(items, key=lambda c: c['order'])

    for i in items:
        image = i.get('image')
        if not image:
            image = 'movieCertificates.jpg'
        i.update({
            'action': 'movies.movielist',
            'url': dbs.resolve('movies{certification}', certification=i['name']),
            'image': image,
        })

    ui.d.adds(items)


@action(str)
def movielist(url):
    items = dbs.movies(url)
    if not items:
        ui.dialog.info(_('No results'))
    else:
        dbs.meta(items, content='movie')
        for i in items:
            i['action'] = actions.url('sources.play', content='movie', meta=i)
            i['next_action'] = 'movies.movielist'

    ui.d.addcontents(items, content='movie')


@action(str)
def personlist(url):
    items = dbs.persons(url)
    if not items:
        ui.dialog.info(_('No results'))
    else:
        for i in items:
            i.update({
                'action': 'movies.movielist',
                'url': dbs.resolve('movies{person_id}', person_id=i['id']),
                'next_action': 'movies.personlist',
            })

    ui.d.adds(items, is_person=True)


@action(str, dict)
def addtolibrary(title, meta):
    meta = meta or {}
    if videolibrary.add('movie', title, meta):
        ui.dialog.info(_('Movie {title} added to the library', title=title))
        actions.run('videolibrary.update', content='movie')
