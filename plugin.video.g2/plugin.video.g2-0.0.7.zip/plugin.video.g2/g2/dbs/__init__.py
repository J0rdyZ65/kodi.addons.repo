# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2020 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import time
from six.moves import urllib

from g2 import pkg
from g2 import defs

from g2.libraries import cache
from g2.libraries.database import Database

from g2.platforms import log
from g2.platforms import addon

from g2.dbs import trakt


class MetaDB(Database):
    name = 'meta'

class Meta(MetaDB):
    def __init__(self, expire=defs.METADATA_CACHE_LIFETIME*3600):
        super(Meta, self).__init__(
            'meta',
            ('lang', 'imdb', 'tmdb', 'tvdb'),
            'item',
            table_constraints=lambda kcns: ''.join([', UNIQUE(lang, {kcn})'.format(kcn=kcn) for kcn in kcns[1:]]),
            where_clause=self.where_clause,
            timestamp=True,
            # (fixme) use a different expiration time for movie (6 months is better) vs tvshow (1 month is OK)
            expire=expire,
            # (notice) v2 because of tvshow/season meta change
            version=2)

    @staticmethod
    def where_clause(kcs):
        if len(kcs) <= 1 or kcs[0][1] != 'lang':
            raise KeyError
        return ' WHERE lang IS ? ' + \
               '   AND ( ' + ' OR '.join(['({kcn} IS ? AND {kcn} IS NOT NULL)'.format(kcn=kc[1]) for kc in kcs[1:]]) + ' )'


def info(package, module):
    if not hasattr(module, 'info'):
        nfo = []
    elif callable(module.info):
        nfo = module.info(package, module)
    else:
        nfo = module.info
    return [dict(nfo)] if isinstance(nfo, dict) else list(nfo)


def resolve(kind=None, **kwargs):
    url = _alldbs_method('resolve', None, kind, **kwargs)
    return url or ''


def movies(url, **kwargs):
    url = resolve(url, **kwargs) or url
    return _alldbs_method('movies', url, url)


def tvshows(url, **kwargs):
    url = resolve(url, **kwargs) or url
    return _alldbs_method('tvshows', url, url)


def meta(items, content='movie', lang=None, season=None, force_refresh=False):
    def content_url(scontent, dbids, season=None):
        for _cycle in range(0, 2):
            for dbid in ('tmdb', 'tvdb', 'imdb'):
                if dbid in dbids:
                    url = resolve('%s_meta{%s}%s{lang}' % (scontent, dbid, '{season}' if season else ''),
                                  season=season, **dbids)
                    if url:
                        return url

            trakt.content_ids(content, dbids)

        return None

    started = time.time()
    lang = lang or addon.content_language()
    dbmods = sorted([d for d in pkg.info('dbs').itervalues() if 'meta' in d.get('methods', []) and d.get('enabled', True)],
                    key=lambda d: d.get('priority', defs.DEFAULT_PACKAGE_PRIORITY))

    add_content = None
    if content == 'season':
        add_content = 'season'
        content = 'tvshow'

    metadb = Meta()

    witems = []
    for item in items:
        dbids = {dbid: item[dbid] for dbid in ('imdb', 'tmdb', 'tvdb') if item.get(dbid)}
        dbids['lang'] = lang

        item_cached = False
        try:
            if force_refresh:
                raise KeyError
            item.update(metadb[dbids])
            log.debug('{m}.{f}: retrieved from the cache for %s %s', content, dbids)
            item_cached = True
        except KeyError:
            url = content_url(content, dbids)
            if url:
                witems.append({
                    'dbids': dbids,
                    'lang': lang,
                    'item': {},
                    'content': content,
                    'url': url,
                    'ritem': item,
                })
                log.debug('{m}.{f}: scheduled fetching for %s %s at %s', content, dbids, url)
            else:
                log.notice('{m}.{f}: no db for %s %s', content, dbids)
                continue

        if add_content != 'season' or not season:
            continue

        try:
            if not any(s['season'] == season and s['season_episodes_meta'] for s in item['seasons']):
                raise KeyError
            log.debug('{m}.{f}: retrieved from the cache for %s %s, season %s', content, dbids, season)
        except Exception:
            url = content_url(add_content, dbids, season)
            if url:
                witems.append({
                    'dbids': dbids,
                    'lang': lang,
                    'item': item if item_cached else witems[-1]['item'],
                    'content': add_content,
                    'season': season,
                    'url': url,
                    'ritem': item,
                })
                log.debug('{m}.{f}: scheduled fetching for %s %s, season %s at %s', content, dbids, season, url)
            else:
                log.notice('{m}.{f}: no db for %s %s, season %s', content, dbids, season)
                continue

    for dbm in dbmods:
        dbwitems = [w for w in witems if urllib.parse.urlparse(w['url']).netloc.lower() in dbm['domains']]
        if dbwitems:
            _db_method(dbm, 'meta', dbwitems)

    for witem in witems:
        if witem['item']:
            log.debug('{m}.{f}: saving meta %s%s',
                      witem['dbids'], '' if 'season' not in witem else ', season %s' % witem['season'])
            metadb[witem['dbids']] = witem['item']
            witem['ritem'].update(witem['item'])

    log.debug('{m}.{f}: %d submitted, %d scheduled, %d completed in %.2f seconds',
              len(items), len(witems), len([w for w in witems if w['item']]), time.time()-started)


def persons(url, **kwargs):
    url = resolve(url, **kwargs) or url
    return _alldbs_method('persons', url, url)


def genres(content='movie'):
    url = resolve('%s_genres{}' % content)
    return _alldbs_method('genres', url, url) or []


def certifications(country='US'):
    url = resolve('certifications{}')
    return _alldbs_method('certifications', url, url, country)


def watched(content, meta_, seen=None):
    if seen is None:
        seen = set()
    _alldbs_method('watched', None, content, meta_, seen)
    return seen


def _alldbs_method(method, url, urlarg, *args, **kwargs):
    def kwargs_get_n_del(kwarg, default=None):
        if kwarg not in kwargs:
            return default
        value = kwargs[kwarg]
        del kwargs[kwarg]
        return value

    netloc = urllib.parse.urlparse(url).netloc.lower() if url else None
    dbmods = sorted([d for d in pkg.info('dbs').itervalues()
                     if method in d.get('methods', []) and (not netloc or netloc in d['domains']) and d.get('enabled', True)],
                    key=lambda d: d.get('priority', defs.DEFAULT_PACKAGE_PRIORITY))
    expire = 0 if '|' not in urlarg else int(urlarg.split('|')[1]) * 60
    dbsopt_provider = kwargs_get_n_del('dbsopt_provider')
    for dbm in dbmods:
        if not expire:
            result = _db_method(dbm, method, urlarg, *args, **kwargs)
        else:
            result = cache.get(_db_method, dbm, method, urlarg, *args, cacheopt_expire=expire, **kwargs)
        if result is not None:
            return result if not dbsopt_provider else dbm['name']

    return None


def _db_method(dbm, method, *args, **kwargs):
    result = None
    try:
        with dbm.context() as modules:
            result = getattr(modules[0], method)(*args, **kwargs)
    except Exception as ex:
        log.debug('{m}.{f}: %s.%s: %s', dbm, method, repr(ex))

    return result
