# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import re
from six.moves import urllib

from g2.libraries import client

from g2.platforms import log

from .lib import kwargs_quote


info = {
    'domains': ['www.imdb.com'],
    'methods': ['resolve', 'movies', 'tvshows'],
}

_BASE_URL = 'https://www.imdb.com'
_URLS = {
    'movies_boxoffice{}': 'search/title?title_type=feature,tv_movie&sort=boxoffice_gross_us,desc&page=1|168',
    'movies_oscar{}': 'search/title?title_type=feature,tv_movie&groups=oscar_best_picture_winners&sort=year,desc&page=1|720',
    'tvshows_emmy{}': 'search/title?title_type=tv_series,tv_miniseries&groups=emmy_winner&page=1|720',
}


def resolve(kind=None, **kwargs):
    if not kind:
        return _URLS.keys()
    if kind not in _URLS:
        return None

    kwargs_quote(kwargs)

    return urllib.parse.urljoin(_BASE_URL, _URLS[kind].format(**kwargs))


def movies(url):
    return _content(url, 'movies')


def tvshows(url):
    return _content(url, 'tvshows')


def _content(url, content):
    if '|' not in url:
        expire = 0
    else:
        url, expire = url.split('|')[0:2]

    result = client.get(url).text
    items = client.parseDOM(result, 'div', attrs={'class': 'lister-item.*?'})
    next_url, next_page, max_pages = _imdb_next_page(url, expire, result)

    log.debug('{m}.{f}: %s: %d %s, next_url=%s, next_page=%s, max_pages=%s',
              url.replace(_BASE_URL, ''), len(items), content, next_url.replace(_BASE_URL, ''), next_page, max_pages)

    videos = []
    for item in items:
        try:
            video = {
                'next_url': next_url,
                'next_page': next_page,
                'max_pages': max_pages,
            }

            video['imdb'] = client.parseDOM(item, 'div', attrs={'class': 'ribbonize'}, ret='data-tconst')[0]
            video['title'] = client.replaceHTMLCodes(client.parseDOM(item, 'a', value_nth=1))
            try:
                year = client.parseDOM(item, 'span', attrs={'class': 'lister-item-year.*?'})[0]
                video['year'] = int(re.search(r'(\d{4})', year).group(1))
            except Exception:
                pass

            try:
                rating = client.parseDOM(item, 'div', attrs={'name': 'ir'}, ret='data-value', value_nth=0)
                votes = client.parseDOM(item, 'span', attrs={'name': 'nv'}, ret='data-value', value_nth=0)
                video['rating'] = float(rating or 0.0)
                video['votes'] = int(votes or 0)
                video['rating_source'] = 'imdb'
            except Exception:
                pass

            videos.append(video)
        except Exception as ex:
            log.debug('{m}.{f}: %s: %s', item, repr(ex))

    return videos


def _imdb_next_page(url, expire, result):
    next_url = ''
    next_page = 0
    max_pages = 0
    next_result = client.parseDOM(result, 'div', attrs={'class': 'desc'})
    if next_result:
        next_url = client.parseDOM(next_result, 'a', attrs={'class': 'lister-page-next.*?'}, ret='href', value_nth=0)
        if next_url:
            next_url = url.replace(urllib.parse.urlparse(url).query, urllib.parse.urlparse(next_url).query)
            if expire:
                next_url += '|' + expire
            try:
                from_item, to_item, num_items = [int(x) for x in re.search(r'(\d+)-(\d+)\s+of\s+(\d+)', next_result).groups()]
                max_pages = int(num_items / (to_item - from_item + 1) + .5)
                next_page = int(to_item / (to_item - from_item + 1)) + 1
            except Exception:
                pass
            if next_page > max_pages:
                next_url = ''
                next_page = 0

    return next_url, next_page, max_pages
