# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

DEFAULT_PACKAGE_PRIORITY = 10
"""Package priority unless redefined by the package itself or configured by the user"""

METADATA_CACHE_LIFETIME = (24*30)
"""Cache lifetime in hours for the video metadata"""

SOURCE_CACHE_LIFETIME = 24
"""Cache lifetime in hours for the video sources"""

MATCH_CACHE_LIFETIME = (24*30)
"""Cache lifetime in hours for the video matches"""

RESOLVER_TIMEOUT = 20
"""Maximum time in seconds to wait for a resolver to provide a result"""

BOOKMARK_THRESHOLD = 2
"""Minimum percentage to pass to save a bookmark"""

WATCHED_THRESHOLD = 90
"""Minimum percentage to pass to update the video watched status"""

TRAKT_CLIENT_ID = 'c67fa3018aa2867c183261f4b2bb12ebb606c2b3fbb1449e24f2fbdbc3a8ffdb'
"""Trakt plugin.video.g2 client id -- do not change unless you know what you are doing!"""

TRAKT_MAX_RECOMMENDATIONS = 60
"""Trakt maximum number of recommendations (the maximum value is 100)"""

TMDB_INCLUDE_ADULT = False
"""Self explaining, isn't? :)"""

TMDB_APIKEY = 'f090bb54758cabf231fb605d3e3e0468'
"""This is the TMDB API key stolen from other addons"""

TVDB_APIKEY = 'FA1E453AC1E9754C'
"""TVDB API key"""
