# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2020 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

from g2 import dbs

from g2.platforms import ui
from g2.platforms import log
from g2.platforms import actions
from g2.platforms import videolibrary
from g2.platforms.language import _
from g2.platforms.actions import action


@action(str, dict)
def add(content, meta):
    meta = meta or {}
    if videolibrary.add(content, meta):
        ui.dialog.info(_('Movie {title} added to library', **meta) if content == 'movie' else
                       _('TV show {title} added to library', **meta) if content == 'tvshow' else '')
        actions.run('videolibrary.update', content=content, meta=meta)


@action(str, dict)
def delete(content, meta):
    meta = meta or {}
    if ui.dialog.yesno(lines=_('Are you sure to delete {title} from the library?', **meta)) and \
       videolibrary.delete(content, meta):
        ui.dialog.info(_('Movie {title} deleted from the library', **meta) if content == 'movie' else
                       _('TV show {title} deleted from the library', **meta) if content == 'tvshow' else '')
        videolibrary.scan(content, clean=True)


@action(str, dict)
def update(content, meta=None):
    meta = meta or {}
    scan = True
    clean = False
    if content == 'tvshow':
        scan = False
        for tvshowtitle, added_episodes, deleted_episodes in videolibrary.update(content, meta, dbs.meta):
            if added_episodes:
                ui.dialog.info(_('{added_episodes} episode(s) added for {tvshowtitle}',
                                 tvshowtitle=tvshowtitle, added_episodes=added_episodes), time=3000)
                log.notice('{m}.{f}: tvshow "%s": %s episode(s) added', tvshowtitle, added_episodes)
                scan = True
            if deleted_episodes:
                clean = True
    if scan:
        videolibrary.scan(content)
    if clean:
        videolibrary.scan(content, clean=True)
