# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2019-2020 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import time
import hashlib

from .database import Database


class StatsDB(Database):
    name = 'stats'
    tables = {
        'search': 0,
        'sources': 1,
        'resolve': 2,
        'play': 3,
    }


def sample(provider, method, *args, **kwargs):
    statsdb = StatsDB(
        method,
        key_columns=(('time', 'INTEGER'), 'provider', 'args'),
        value_columns=
        (('elapsed', 'REAL'), ('matches', 'INTEGER'), ('best', 'INTEGER'), 'exc') if method == 'search' else
        (('elapsed', 'REAL'), ('sources', 'INTEGER'), 'exc') if method == 'sources' else
        (('elapsed', 'REAL'), 'resolver', 'exc') if method == 'resolve' else
        (('elapsed', 'REAL'), 'host', 'exc') if method == 'play' else None,
        version=1)

    if not args:
        args_hash = '0'
    else:
        args_hash = hashlib.md5()
        for arg in args:
            args_hash.update(repr(arg))
        args_hash = args_hash.hexdigest()

    statsdb[(int(time.time()), provider, args_hash)] = kwargs
