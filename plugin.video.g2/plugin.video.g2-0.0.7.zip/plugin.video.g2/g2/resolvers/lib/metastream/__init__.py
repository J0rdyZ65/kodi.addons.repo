# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Based on the original idea/code of boogiekodi@GitHub for his ump plugin
    Copyright (C) 2016-2020 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import struct

import importer

from g2.platforms import log


# Do not read more that 100KB in the stream to look for the resolution
_MAX_READ_BYTES = 100 * 1024

_MODULES = [str(n) for _d, n, _d in importer.walk_packages([os.path.dirname(__file__)], onerror=lambda name: True)] # [py2] str() for non unicode modules names!
_METASTREAM = __import__('', globals(), locals(), _MODULES, 1)
_MODULES = {n: getattr(_METASTREAM, n) for n in _MODULES}


def video(fil):
    # NOTE: assumption here is that the first 8 bytes are enough to detect the file type
    first8bytes = fil.read(8)
    meta = {}
    for name, module in _MODULES.iteritems():
        try:
            meta['width'], meta['height'] = module.video_resolution(first8bytes, fil, _MAX_READ_BYTES, log=log.debug)
            meta['type'] = name
            if meta['width'] < 0 or meta['height'] < 0:
                meta['type'] += '?'
            break
        except Exception as ex:
            log.debug('{m}.{f}: %s', ex)
    else:
        meta['firstbytes'] = first8bytes

    return meta
