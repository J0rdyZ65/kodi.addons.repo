# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2020 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import re
import json
import errno

import xbmc
import xbmcvfs

from . import log
from . import info as platforminfo
from . import addon
from . import actions


class File(object):
    def __init__(self, filepath, mode='r', ignore_exc=True):
        self.filepath = filepath
        self.mode = mode
        self.ignore_exc = ignore_exc
        self.fil = None

    def __enter__(self):
        try:
            # Not strictly required but this check avoids Kodi to spit out
            # an error message on behalf of the xbmcvfs.File builtin
            if 'r' in self.mode and not xbmcvfs.exists(self.filepath):
                raise OSError(errno.ENOENT, os.strerror(errno.ENOENT), self.filepath)
            self.fil = xbmcvfs.File(self.filepath, self.mode)
        except Exception:
            if not self.ignore_exc:
                raise
        return self.fil

    def __exit__(self, exc_type, exc_value, traceback):
        if self.fil:
            self.fil.close()
        return self.ignore_exc or not exc_value


_STRM_SUFFIX = '.strm'
_NFO_SUFFIX = '.nfo'

_NFO_URLS = {
    'movie': (
        'https://www.themoviedb.org/movie/{tmdb}',
        'http://www.imdb.com/title/{imdb}/',
    ),
    'tvshow': (
        'https://www.themoviedb.org/tv/{tmdb}',
        'http://thetvdb.com/?tab=series&id={tvdb}',
        'http://www.imdb.com/title/{imdb}/',
    ),
}

_CONTENT_LIBRARY_SETTINGS = {
    'movie': 'videolibrary.movies',
    'tvshow': 'videolibrary.tvshows',
}


def add(content, meta):
    path = _content_path(content, meta)
    return path and _content_add_nfo(path, content, meta)


def exists(content, meta):
    path = _content_path(content, meta)
    return path and xbmcvfs.exists(path)


def delete(content, meta):
    def _remove_dir(path):
        if not xbmcvfs.exists(path):
            return False
        dirs, files = xbmcvfs.listdir(path)
        return all([_remove_dir(os.path.join(path, d.decode('utf-8'), '')) for d in dirs] +
                   [xbmcvfs.delete(os.path.join(path, f.decode('utf-8'))) for f in files] +
                   [xbmcvfs.rmdir(path)])

    return _remove_dir(_content_path(content, meta))


def update(content, meta=None, dbs_meta=None):
    if content == 'movie' and meta:
        path = _content_path(content, meta)
        if path:
            _create_strm(os.path.join(path, 'movie' + _STRM_SUFFIX), content, meta)
        return

    if content != 'tvshow':
        return

    for path, tvshow in _content_iter(content, meta):
        if callable(dbs_meta):
            dbs_meta([tvshow], content='tvshow')
            for season in tvshow.get('seasons') or []:
                dbs_meta([tvshow], content='season', season=season['season'])

        if not tvshow.get('title'):
            continue

        library_eps = [(ep['season'], ep['episode'], ep.get('title'))
                       for ep in _fetch_local_content('episode', tvshowtitle=tvshow['title'], **tvshow)]

        # Dict of episodes' strm files keyed by filename substring up to ' - '
        library_strms = {
            os.path.splitext(ep_strm.decode('utf-8'))[0].split(' - ')[0]:
            os.path.join(path, season_dir.decode('utf-8'), ep_strm.decode('utf-8'))
            for season_dir in xbmcvfs.listdir(path)[0]
            for ep_strm in xbmcvfs.listdir(os.path.join(path, season_dir.decode('utf-8')))[1]
        }

        def add_or_update_strm(library_strms, tvshow, episode):
            strm_fpath = os.path.join(path,
                                      'S{season:02d}'.format(**episode),
                                      '{season}x{episode:02d} - {title}'.format(**episode) + _STRM_SUFFIX)
            strm_fpath = xbmc.makeLegalFilename(strm_fpath).decode('utf-8')
            old_strm_fpath = library_strms.get('{season}x{episode:02d}'.format(**episode))
            deleted = 0
            if old_strm_fpath and old_strm_fpath != strm_fpath:
                xbmcvfs.delete(old_strm_fpath)
                deleted += 1
            episode.update({dbid: tvshow[dbid] for dbid in ('imdb', 'tmdb', 'tvdb') if dbid in tvshow})
            episode['tvshowtitle'] = tvshow['title']
            episode['originaltvshowtitle'] = tvshow.get('originaltitle')
            return _create_strm(strm_fpath, 'episode', episode), deleted

        # Add/update an episode if not present or the title changed (e.g meta has been updated)
        strms_add_del = [add_or_update_strm(library_strms, tvshow, ep) for ep in tvshow.get('episodes') or []
                         if (ep.get('season'), ep.get('episode'), ep.get('title')) not in library_eps]

        yield os.path.basename(os.path.dirname(path)), sum(s[0] for s in strms_add_del), sum(s[1] for s in strms_add_del)


def scan(content, clean=False):
    # (notice) give a chance to kodi to actually start the scan
    xbmc.sleep(2000)
    # (fixme) or kodi terminated
    while xbmc.getCondVisibility('Library.IsScanningVideo'):
        xbmc.sleep(1000)
    if clean:
        xbmc.executebuiltin('CleanLibrary(video)')
    else:
        xbmc.executebuiltin('UpdateLibrary(video)')


def watched(content, meta, seen):
    if content == 'movie':
        local_content = 'movie'
    elif content in ('tvshow', 'season', 'episode'):
        local_content = 'episode'
    else:
        return None
    videos = _fetch_local_content(local_content, **meta)
    if not videos:
        return None

    if isinstance(seen, set):
        seenlen = len(seen)
        if content == 'movie':
            movie = videos[0]
            seen.update([True] if movie.get('playcount') else [])
        elif content == 'tvshow':
            seen.update([(e['episode'], e['season']) for e in videos if e.get('playcount')])
        elif content == 'season':
            seen.update([(e['episode'], e['season']) for e in videos if e.get('playcount') and
                         e['season'] == meta['season']])
        elif content == 'episode':
            episodes = [e for e in videos if e.get('playcount') and
                        e['season'] == meta['season'] and e['episode'] == meta['episode']]
            seen.update([True] if episodes and episodes[0].get('playcount') else [])
        if seenlen != len(seen):
            log.debug('{m}.{f}: %s %s/%s/%s: %s [%d]',
                      content, meta.get('imdb'), meta.get('season'), meta.get('episode'), seen, len(seen))

    elif content == 'movie':
        movie = videos[0]
        movie['playcount'] = 1 if seen else 0
        res = _update_local_content(local_content, **movie)
        log.debug('{m}.{f}: %s %s: seen=%s, res=%s', content, meta.get('imdb'), seen, res)

    else:
        # (fixme) [FUNC] massive episode playcount update (e.g. entire tvshow and season updates) is disabled
        # for the UI side effect that for each episode update a refresh of the current container is forced.
        if content == 'tvshow':
            episodes = [] # videos
        elif content == 'season':
            episodes = [] # [e for e in videos if e['season'] == meta['season']]
        elif content == 'episode':
            episodes = [e for e in videos if e['season'] == meta['season'] and e['episode'] == meta['episode']]
        for episode in episodes:
            episode['playcount'] = 1 if seen else 0
            res = _update_local_content(local_content, **episode)
            log.debug('{m}.{f}: %s %s/%s/%s: seen=%s, res=%s',
                      content, meta.get('imdb'), episode.get('season'), episode.get('episode'), seen, res)

    return None


def search(content, meta):
    if content == 'movie':
        videos = _fetch_local_content(content, **meta)
    elif content == 'episode':
        videos = [v for v in _fetch_local_content(content, **meta)
                  if v['season'] == meta['season'] and v['episode'] == meta['episode']]
    else:
        return []
    return [v for v in videos if not v['file'].endswith(_STRM_SUFFIX)]


def mediainfo(content, videoid):
    if content == 'movie':
        video = _json_rpc('details.movie', movieid=videoid)['result']['moviedetails']['streamdetails']['video']
    elif content == 'episode':
        video = _json_rpc('details.episode', episodeid=videoid)['result']['episodedetails']['streamdetails']['video']
    else:
        return []
    return video


def _content_iter(content, meta):
    folder_path = xbmc.translatePath(addon.setting(_CONTENT_LIBRARY_SETTINGS.get(content, ''))).decode('utf-8') # dirname
    if folder_path and xbmcvfs.exists(os.path.join(folder_path, '')):
        if meta is not None:
            content_path = _content_path(content, meta)
            yield content_path, meta
        else:
            for path in xbmcvfs.listdir(folder_path)[0]: # dirnames
                content_path = os.path.join(folder_path, path.decode('utf-8'), '')
                content_meta = _content_get_nfo(content_path, content)
                if content_meta:
                    yield content_path, content_meta


def _content_path(content, meta):
    folder_path = xbmc.translatePath(addon.setting(_CONTENT_LIBRARY_SETTINGS.get(content, ''))).decode('utf-8') # dirname
    if not folder_path or not xbmcvfs.exists(os.path.join(folder_path, '')):
        return None

    try:
        folder_cache = _content_path.folder_cache
    except Exception:
        folder_cache = _content_path.folder_cache = addon.prop('videolibrary', name='folder_cache') or {}

    # Rebuild the library cache if empty or the the root folder changed
    mtime = xbmcvfs.Stat(folder_path).st_mtime()
    if folder_cache.get('') != mtime:
        log.debug('{m}.{f}: rebuilding the cache ("%s" vs "%s")', folder_cache.get(''), mtime)
        folder_cache[''] = mtime
        for path in xbmcvfs.listdir(folder_path)[0]: # dirnames
            content_path = os.path.join(folder_path, path.decode('utf-8'))
            dbids = _content_get_nfo(content_path, content)
            for dbid in ('tmdb', 'tvdb', 'imdb'):
                if dbid in dbids:
                    log.debug('{m}.{f}: cached {"%s.%s": %s}', dbid, dbids[dbid], content_path)
                    folder_cache['%s.%s' % (dbid, dbids[dbid])] = os.path.join(content_path, '')
        addon.prop('videolibrary', folder_cache, name='folder_cache')
        _content_path.folder_cache = folder_cache

    # Search in the library cache first
    for dbid in ('tmdb', 'tvdb', 'imdb'):
        content_path = folder_cache.get('%s.%s' % (dbid, meta.get(dbid)))
        if content_path:
            return content_path

    # If not in the cache, build a new path
    content_path = folder_path
    if content == 'movie' and meta.get('year'):
        content_path = os.path.join(folder_path, str(meta['year']))

    try:
        video_dir = '{title} ({year})'.format(**meta)
    except Exception:
        video_dir = meta['title']

    return xbmc.makeLegalFilename(os.path.join(content_path, video_dir, '')).decode('utf-8')


def _content_add_nfo(path, content, meta):
    xbmcvfs.mkdirs(path)
    nfo_fname = os.path.join(path, content + _NFO_SUFFIX)
    with File(nfo_fname, 'w') as fil:
        for url in _NFO_URLS.get(content, ()):
            try:
                nfo_content = url.format(**meta)
                fil.write((nfo_content + '\n').encode('utf-8'))
            except Exception:
                pass

        return fil.size() > 0


def _content_get_nfo(path, content):
    nfo_fname = os.path.join(path, content + _NFO_SUFFIX)
    if not xbmcvfs.exists(nfo_fname):
        return {}

    with File(nfo_fname) as fil:
        nfo = fil.read()

    meta = {}
    for url in _NFO_URLS.get(content, ()):
        try:
            placeholders = []
            def scan_placeholder(match):
                placeholders.append(match.group(1)) #pylint: disable=W0640
                return '(.*)'

            pat = re.sub(r'\\{([a-zA-Z_]*)\\}', scan_placeholder, re.escape(url))
            match = re.search(pat, nfo)
            if match:
                for value in match.groups():
                    meta.update({placeholders.pop(0): value})
        except Exception:
            pass

    return meta


def _create_strm(strm_fpath, content, meta):
    strm_content = actions.url('sources.play', content=content, meta=meta)
    xbmcvfs.mkdirs(os.path.dirname(strm_fpath))
    with File(strm_fpath, 'w') as fil:
        fil.write((strm_content + '\n').encode('utf-8'))
    return 1


def _fetch_local_content(content, **meta):
    year = meta.get('year', 0)
    try:
        if content == 'movie':
            res = _json_rpc(content, **meta)['result']['movies']
            return [i for i in res
                    if not year or not i.get('year') or any(y == i.get('year') for y in range(year-1, year+2))]
        if content == 'episode':
            if not meta.get('tvshowtitle') and meta.get('title'):
                meta['tvshowtitle'] = meta['title']
            res = _json_rpc('tvshow', **meta)['result']
            if 'tvshows' in res:
                res = res['tvshows']
            elif int(platforminfo('version.major')) <= 16:
                # Hack to reconciliate the tvdb addon meta fetching in kodi16 which appends
                # the (US) tag to some tvshows titles (e.g. 'Shameless' becomes 'Shameless (US)')
                meta = dict(meta)
                meta['tvshowtitle'] += ' (US)'
                res = _json_rpc('tvshow', **meta)['result']['tvshows']
            tvshowids = [i['tvshowid'] for i in res
                         if not year or not i.get('year') or any(y == i.get('year') for y in range(year-1, year+2))]
            return _json_rpc(content, tvshowid=tvshowids[0], **meta)['result']['episodes']
    except Exception:
        pass
    return []


def _update_local_content(content, **meta):
    try:
        return _json_rpc('update.' + content, **meta)
    except Exception:
        return {}


def _json_rpc(method, **meta):
    for method_template in _JSON_METHODS_TEMPLATES.get(method, []):
        try:
            _json_rpc.request_id += 1
        except Exception:
            _json_rpc.request_id = 1
        try:
            method_instance = method_template.format(_request_id=_json_rpc.request_id, **meta)
            log.debug('{m}.{f}: json method: %s', method_instance)
            method_result = xbmc.executeJSONRPC(method_instance.encode('utf-8')).decode('utf-8')
            log.debug('{m}.{f}: json result: %s', method_result)
            return json.loads(method_result)
        except Exception as ex:
            log.debug('{m}.{f}: %s', ex)
    return {}


_JSON_METHODS_TEMPLATES = {
    'movie': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.GetMovies", \
            "params": {{ \
                "filter": {{"operator": "is", "field": "title", "value": "{title}"}}, \
                "properties": ["title", "file", "year", "playcount"] \
            }} \
        }}',
    ],
    'details.movie': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.GetMovieDetails", \
            "params": {{ \
                "movieid": {movieid}, \
                "properties": ["streamdetails"] \
            }} \
        }}',
    ],
    'update.movie': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.SetMovieDetails", \
            "params": {{ \
                "movieid": {movieid}, \
                "playcount": {playcount} \
            }} \
        }}',
    ],
    'tvshow': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.GetTVShows", \
            "params": {{ \
                "filter": {{"operator": "is", "field": "title", "value": "{tvshowtitle}"}}, \
                "properties": ["year"] \
            }} \
        }}',
    ],
    'episode': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.GetEpisodes", \
            "params": {{ \
                "tvshowid": {tvshowid}, \
                "properties": ["showtitle", "title", "file", "season", "episode", "playcount"] \
            }} \
        }}',
    ],
    'details.episode': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.GetEpisodeDetails", \
            "params": {{ \
                "episodeid": {episodeid}, \
                "properties": ["streamdetails"] \
            }} \
        }}',
    ],
    'update.episode': [
        '{{"jsonrpc": "2.0", \
            "id": "{_request_id}", \
            "method": "VideoLibrary.SetEpisodeDetails", \
            "params": {{ \
                "episodeid": {episodeid}, \
                "playcount": {playcount} \
            }} \
        }}',
    ],
}
