# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2018-2019 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from __future__ import unicode_literals

import os
import ast
from xml.dom import minidom

import xbmc
import xbmcgui
import xbmcaddon


_DEFAULT_MAX_CONCURRENT_THREADS = 10


class MonitorSettings(xbmc.Monitor):
    def __init__(self, *args, **kwargs):
        super(MonitorSettings, self).__init__(*args, **kwargs)
        self.addon = None
        self.callbacks = []
        self.onSettingsChanged()

    def onSettingsChanged(self): #pylint: disable=C0103
        self.addon = xbmcaddon.Addon()
        for callback in self.callbacks:
            callback()

    def on_settings_change(self, callback):
        if callable(callback) and callback not in self.callbacks:
            self.callbacks.append(callback)

    def get_setting(self, setid):
        return self.addon.getSetting(setid)

    def set_setting(self, setid, value):
        self.addon.setSetting(setid, value)


_MONITOR_SETTINGS = MonitorSettings()
_HOME_WINDOW = 10000
_ADDON = xbmcaddon.Addon()
_PATH = xbmc.translatePath(_ADDON.getAddonInfo('path')).decode('utf-8') # decode kodi dirname
_INFOS = {
    'id': _ADDON.getAddonInfo('id'),
    'name': _ADDON.getAddonInfo('name'),
    'version': _ADDON.getAddonInfo('version'),
    'version.major.minor': '.'.join(_ADDON.getAddonInfo('version').split('.')[0:2]),
    'path': _PATH,
    'resources': os.path.join(_PATH, 'resources'),
    'changelog': os.path.join(_PATH, 'changelog.txt'),
    'icon': _ADDON.getAddonInfo('icon'),
    'fanart': _ADDON.getAddonInfo('fanart'),
}


def exists(addon):
    return xbmc.getCondVisibility('System.HasAddon(%s)' % addon)


def info(nfo, default=None):
    if nfo == 'profile':
        return xbmc.translatePath(_ADDON.getAddonInfo('profile')).decode('utf-8') # decode kodi filename
    return _INFOS.get(nfo, default)


def info2(addon, nfo):
    if nfo == 'resources':
        res = os.path.join(xbmcaddon.Addon(addon).getAddonInfo('path').decode('utf-8'), 'resources') # decode kodi filename
    elif nfo == 'search_paths':
        res = _get_addon_search_paths(addon)
    else:
        res = xbmcaddon.Addon(addon).getAddonInfo(nfo)
    return res if res not in ('path', 'resources', 'profile') else xbmc.translatePath(res).decode('utf-8') # decode kodi dirname


def on_settings_change(callback):
    _MONITOR_SETTINGS.on_settings_change(callback)


def setting(setid, value=None):
    if value is not None:
        _MONITOR_SETTINGS.set_setting(setid, value)
    return _MONITOR_SETTINGS.get_setting(setid)


def content_language(fmt='ISO_639_1'):
    lang = setting('content_language')
    lang = xbmc.getLanguage(xbmc.ISO_639_1) if not lang or lang.upper() == 'AUTO' else lang
    return xbmc.convertLanguage(lang.lower(), xbmc.ISO_639_1 if fmt == 'ISO_639_1' else xbmc.ENGLISH_NAME)


def max_concurrent_threads():
    try:
        return int(setting('max_concurrent_threads'))
    except Exception:
        return _DEFAULT_MAX_CONCURRENT_THREADS


def prop(module='', value=None, name='status', addon=info('id')):
    prop_name = addon
    if module:
        prop_name += ('.' if prop_name else '') + module
    if name:
        prop_name += ('.' if prop_name else '') + name
    home_win = xbmcgui.Window(_HOME_WINDOW)
    if value is None:
        value = home_win.getProperty(prop_name)
        try:
            return ast.literal_eval(value or 'None')
        except Exception:
            return None
    elif value == '':
        home_win.clearProperty(prop_name)
    else:
        home_win.setProperty(prop_name, repr(value))

    return prop_name


def _get_addon_search_paths(addon):
    search_paths = []
    search_path, imported_addons = _get_addon_details(addon, ['search_path', 'imported_addons'])
    if search_path:
        search_paths.append(search_path)
        for imported_addon in imported_addons:
            search_paths.extend(_get_addon_search_paths(imported_addon))
    return search_paths


def _get_addon_details(addon, details_ids):
    try:
        # If not checked in advance the presence of an addon,
        # the info2 will log an exception in the logfile even if catched
        if not exists(addon) or not details_ids:
            raise Exception('addon not existing or no details requested')
        addon_path = info2(addon, 'path')
        addon_xml_doc = minidom.parse(os.path.join(addon_path, 'addon.xml'))
    except Exception:
        return [None for dummy in details_ids]

    details = []
    for did in details_ids:
        if did == 'search_path':
            # <extension point="xbmc.python.module" library="lib" />
            lib_paths = [e.getAttribute('library') for e in addon_xml_doc.getElementsByTagName('extension')
                         if e.getAttribute('point') == 'xbmc.python.module']
            if lib_paths:
                addon_path = os.path.join(addon_path, lib_paths[0])
            details.append(xbmc.translatePath(addon_path).decode('utf-8')) # decode kodi dirname
        elif did == 'imported_addons':
            # <import addon="script.module.requests" version="2.9.1"/>
            imported_addons = [i.getAttribute('addon') for i in addon_xml_doc.getElementsByTagName('import')]
            imported_addons = [a for a in imported_addons if a and not a.startswith('xbmc.')]
            details.append(imported_addons)
        else:
            details.append(None)

    return details
