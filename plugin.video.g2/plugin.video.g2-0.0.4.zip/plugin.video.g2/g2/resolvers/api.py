# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import abc

from g2.pkg import setting


class ResolverError(Exception):
    pass


class ResolverBase(object): # pylint: disable=abstract-class-little-used
    __metaclass__ = abc.ABCMeta

    def __init__(self, module, resolver, package):
        self.module = module
        self.resolver = resolver
        self.package = package if package is not None else resolver.package

    def setting(self, setid):
        """Helper method to retrieve the module settings

        Args:
            setid (str): the setting identifier

        Returns:
            str: the setting value
        """
        if not self.package or not self.resolver:
            return ''
        return setting('resolvers', self.package['name'], self.resolver['name'], setid)

    @property
    @abc.abstractmethod
    def info(self):
        """(fixme) TO BE DOCUMENTED"""
        raise NotImplementedError

    @abc.abstractmethod
    def resolve(self, url):
        """(fixme) TO BE DOCUMENTED"""
        raise NotImplementedError


class Resolver(ResolverBase):
    """Dummy Resolver class for packages' info property probing"""

    info = {}

    def resolve(self, url):
        return ResolverError()


def create(module, resolver=None, package=None):
    if package is None:
        package = resolver.package
    adapterclass = package.get('__adapterclass__')
    if not adapterclass:
        apiclass = module.Resolver if module else Resolver
    else:
        apiclass = getattr(__import__(package['name'], globals(), locals(), [], -1), adapterclass)
    return apiclass(module, resolver, package)
