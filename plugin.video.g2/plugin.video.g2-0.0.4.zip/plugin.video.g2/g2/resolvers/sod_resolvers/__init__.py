# -*- coding: utf-8 -*-

"""Streamondemand package descriptor and API adapter"""

kind = 'resolvers'

addons = ['plugin.video.streamondemand']

imports = ['servers']

paths = ['lib']

nick = 'sod'


import os

from g2.libraries import fs
from g2.libraries import log
from g2.libraries import client

from g2.resolvers.api import ResolverBase


class SODResolvers(ResolverBase):
    @property
    def info(self):
        if not self.module:
            return {}

        from core import logger # kodi addon # pylint: disable=import-error
        logger.log_enable(False)

        module_path = os.path.splitext(self.module.__dict__['__file__'])[0]
        module_name = os.path.basename(module_path)
        if not hasattr(self.module, 'get_video_url'):
            log.debug('{p}.{f}: %s: missing get_video_url function', module_name)
            return []

        url_patterns = []
        with fs.File(module_path + '.xml') as fil:
            xml = fil.read()
            active = client.parseDOM(xml, 'active')
            if not active or active[0].lower() != 'true':
                log.debug('{p}.{f}: %s: server not active', module_name)
                return []
            patterns = client.parseDOM(xml, 'patterns')
            for pattern in patterns:
                pattern = client.parseDOM(pattern, 'pattern')
                for pat in pattern:
                    url_patterns.append(pat)

        if not url_patterns:
            log.debug('{p}.{f}: %s: url patterns not found', module_name)
            return []                      

        log.debug('{p}.{f}: %s: url patterns: %s', module_name, url_patterns)

        return [{
            'name': module_name,
            'url_patterns': url_patterns,
        }]

    def resolve(self, url):
        urls = self.module.get_video_url(url)
        if not urls:
            return None

        # (fixme) the url resolution might return multiple urls with different stream quality,
        # this should be handled in the resolvers.resolve.
        for url in urls:
            log.debug('{m}.{f}: %s', url)

        return urls[-1][1]
