# -*- coding: utf-8 -*-

"""URLResolver package descriptor and API adapter"""

kind = 'resolvers'

addons = ['script.module.urlresolver']

imports = 'urlresolver'

nick = 'smu'


import ast

from g2.libraries import log
from g2.resolvers.api import ResolverBase


class SMUResolvers(ResolverBase):
    default_allow_popups = True

    @property
    def info(self):
        if not self.module:
            return {'settings': [{'id': 'allow_popups',
                                  # (fixme) language.translations('english', {'it': 'italian', ...})
                                  'label': 'Allow popups',
                                  'spec': 'type="bool"',
                                  'default': str(self.default_allow_popups).lower()}]}

        try:
            resolvers = self.module.relevant_resolvers(include_universal=True, include_external=True)
        except Exception as ex:
            log.error('{p}.{f}: %s', repr(ex))
            return []

        nfo = []
        for res in resolvers:
            nfo.append({
                'name': res.name,
                'domains': res.domains,
            })
            log.debug('{m}.{f}: %s: domains: %s', res.name, res.domains)

        return nfo

    def resolve(self, url):
        return self.module.HostedMediaFile(url=url).resolve(allow_popups=self._allow_popups())

    def _allow_popups(self):
        try:
            allow_popups = self.setting('allow_popups')
            allow_popups = ast.literal_eval(allow_popups.capitalize()) if allow_popups else self.default_allow_popups
        except Exception:
            allow_popups = self.default_allow_popups
        return allow_popups
