# -*- coding: utf-8 -*-

kind = 'providers'

addons = ['script.module.unidecode']
