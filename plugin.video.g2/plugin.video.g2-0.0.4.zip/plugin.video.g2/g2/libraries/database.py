# -*- coding: utf-8 -*-

"""
    G2 Add-on
    Copyright (C) 2016-2017 J0rdyZ65

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


import os
import json
import time
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

from g2.libraries import fs
from g2.libraries import log
from g2.libraries import addon


_DEFAULT_DB_TIMEOUT = 10
_TIMESTAMP_COLUMN = 'timestamp'


class Database(dict):
    def __init__(self, name, table, *columns_def, **kwargs):
        dict.__init__(self)
        self.name = name or 'settings'
        self.table = table
        self.timeout = kwargs.get('timeout', _DEFAULT_DB_TIMEOUT)
        self.expire = kwargs.get('expire', False)
        self.timestamp = kwargs.get('timestamp', False) or self.expire
        self.columns_def = columns_def + (((_TIMESTAMP_COLUMN, 'INTEGER'),) if self.timestamp else ())
        self.sql_cmd_templates = {}
        for sql_cmd in ('create', 'select', 'replace', 'delete', 'selectall'):
            self.sql_cmd_templates[sql_cmd] = kwargs.get(sql_cmd)

    def _dbconnect(self):
        fs.makeDir(addon.PROFILE_PATH)
        dbcon = database.connect(os.path.join(addon.PROFILE_PATH, self.name + '.db'), self.timeout)
        dbcon.row_factory = database.Row
        return dbcon

    def _sql_cmd(self, sql_cmd, star='*'):
        # (fixme) cache the sql_cmds
        if sql_cmd not in self.sql_cmd_templates:
            raise NotImplementedError
        try:
            columns_def = ', '.join([' '.join(c) for c in self.columns_def])
            columns = ', '.join([c[0] for c in self.columns_def])
            values = ', '.join(['?' for c in self.columns_def])
            return self.sql_cmd_templates[sql_cmd].format(table=self.table,
                                                          columns_def=columns_def,
                                                          columns=columns,
                                                          timestamp=_TIMESTAMP_COLUMN,
                                                          values=values,
                                                          star=star)
        except Exception:
            raise NotImplementedError

    def _get(self, keys):
        select_cmd = self._sql_cmd('select')
        try:
            dbcur = self._dbconnect().execute(select_cmd, keys)
            while True:
                row = dbcur.fetchone()
                if not row:
                    break
                if not self.expire or row[_TIMESTAMP_COLUMN] + self.expire >= time.time():
                    return row
        except Exception as ex:
            log.debug('{m}.{f}: select %s.%s%s: %s', self.name, self.table, keys, repr(ex))
        return {}

    def _set(self, keys, values):
        create_cmd = self._sql_cmd('create')
        replace_cmd = self._sql_cmd('replace')
        try:
            with self._dbconnect() as dbcon:
                dbcon.execute(create_cmd)
                dbcon.execute(replace_cmd, keys+values+((time.time(),) if self.timestamp else ()))
        except Exception as ex:
            log.debug('{m}.{f}: replace %s.%s%s=%s: %s', self.name, self.table, keys, values, repr(ex))

    def _del(self, keys):
        delete_cmd = self._sql_cmd('delete')
        try:
            with self._dbconnect() as dbcon:
                dbcon.execute(delete_cmd, keys)
        except Exception as ex:
            log.debug('{m}.{f}: delete %s.%s%s: %s', self.name, self.table, keys, repr(ex))

    def get(self, key, default=None):
        try:
            return self.__getitem__(key)
        except KeyError:
            return default

    def __iter__(self):
        return DatabaseIterator(self._dbconnect(), self.columns_def, self._sql_cmd('selectall'))

    def __len__(self):
        countall_cmd = self._sql_cmd('selectall', star='COUNT(*)')
        try:
            dbcur = self._dbconnect().execute(countall_cmd)
            return dbcur.fetchone()[0]
        except Exception as ex:
            log.debug('{m}.{f}: select %s.%s(*): %s', self.name, self.table, repr(ex))
            raise


class DatabaseIterator(object):
    def __init__(self, dbcon, columns_def, selectall_cmd):
        self.dbcon = dbcon
        self.columns_def = columns_def
        self.selectall_cmd = selectall_cmd
        self.dbcur = None

    def __iter__(self):
        return self

    def next(self):
        if not self.dbcur:
            self.dbcur = self.dbcon.execute(self.selectall_cmd)
        row = self.dbcur.fetchone()
        if not row:
            raise StopIteration
        return row


class DictDatabase(Database):
    def __init__(self, name, table, key_column, value_column):
        Database.__init__(self,
                          name, table,
                          (key_column, 'TEXT'),
                          (value_column, 'TEXT'),
                          create='CREATE TABLE IF NOT EXISTS {table} ({columns_def}, UNIQUE(%s))' % key_column,
                          select='SELECT {star} FROM {table} WHERE %s = ?' % key_column,
                          replace='REPLACE INTO {table} ({columns}) VALUES ({values})',
                          delete='DELETE FROM {table} WHERE %s = ?' % key_column)
        self.value_column = value_column

    def __getitem__(self, key):
        row = Database._get(self, (key,))
        if not row:
            raise KeyError
        return json.loads(row[self.value_column])

    def __setitem__(self, key, value):
        Database._set(self, (key,), (json.dumps(value),))

    def __delitem__(self, key):
        Database._del(self, (key,))


class SettingsDatabase(DictDatabase):
    def __init__(self):
        DictDatabase.__init__(self, 'settings', 'settings', 'name', 'value')
